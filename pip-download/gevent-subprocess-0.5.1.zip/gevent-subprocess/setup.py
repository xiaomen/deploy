import os
from distutils.command.sdist import sdist
from setuptools import setup, find_packages
 
class sdist_hg(sdist):
    user_options = sdist.user_options + [
            ('dev', None, "Add a dev marker")
            ]

    def initialize_options(self):
        sdist.initialize_options(self)
        self.dev = 0

    def run(self):
        if self.dev:
            suffix = '.dev%d' % self.get_tip_revision()
            self.distribution.metadata.version += suffix
        sdist.run(self)

    def get_tip_revision(self, path=os.getcwd()):
        from mercurial.hg import repository
        from mercurial.ui import ui
        from mercurial import node
        repo = repository(ui(), path)
        tip = repo.changelog.tip()
        return repo.changelog.rev(tip)

setup(
    name = 'gevent-subprocess',
    version = '0.5.1',
    author = 'Erik Scheffers',
    author_email = 'e.t.j.scheffers@tue.nl',
    description = "subprocess.Popen implementation for gevent using pipes for communication",
    url = 'http://hg.peach3.nl/gevent-subprocess/',
    install_requires = [
        'gevent<0.14',
    ],
    packages = find_packages('src'),
    package_dir = {'': 'src'},
    test_suite = 'test',
    zip_safe = True,
    classifiers = [
        'Development Status :: 4 - Beta',
        'Intended Audience :: Developers',
        'License :: OSI Approved :: Artistic License',
        'Operating System :: POSIX',
        'Programming Language :: Python :: 2.6',
        'Topic :: System :: Monitoring',
        'Topic :: Software Development :: Libraries :: Python Modules',
    ],
    cmdclass={'sdist': sdist_hg}
)
