.. gevent-subprocess documentation master file, created by
   sphinx-quickstart on Fri Mar 25 13:11:20 2011.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to gevent-subprocess's documentation!
=============================================

Contents:

.. toctree::
   :maxdepth: 2

   gevsubprocess
   gevsubprocess.pipe

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

