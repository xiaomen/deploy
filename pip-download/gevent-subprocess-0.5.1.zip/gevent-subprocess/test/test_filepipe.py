import unittest
import os
import tempfile

import gevent

from gevsubprocess.pipe import Pipe, pipe_to_file, file_to_pipe

class TestFilePipe(unittest.TestCase):
    TESTFILE = __file__
    
    def get_content(self, name):
        result = []
        with open(name, 'r') as f:
            while True:
                chunk = f.read()
                if not chunk:
                    return ''.join(result)
                result.append(chunk)
        
    def assertEqualFiles(self, name1, name2, msg=None):
        if self.get_content(name1) != self.get_content(name2): 
            raise self.failureException, (msg or 'content of files is not the same')
    
    def test_file2pipe(self):
        with gevent.Timeout(1):
            file = open(self.TESTFILE, 'r')
            pipe = Pipe()
            
            gevent.spawn_link_exception(file_to_pipe, file, pipe).join()

            result = ''.join(chunk for chunk in pipe)
            
            self.assertTrue(file.closed)
            self.assertTrue(pipe.finished())
            
            self.assertEqual(result, self.get_content(self.TESTFILE))
            
    def test_pipe2file(self):
        with gevent.Timeout(1):
            pipe = Pipe()
            file = tempfile.NamedTemporaryFile(delete=False)
            
            try:
                pf = gevent.spawn_link_exception(pipe_to_file, pipe, file)
                
                with open(self.TESTFILE, 'r') as infile:
                    for line in infile:
                        pipe.put(line)

                pipe.close()
                pf.join()

                self.assertTrue(file.closed)
                self.assertTrue(pipe.finished())

                self.assertEqualFiles(self.TESTFILE, file.name)
                
            finally:
                try:
                    os.remove(file.name)
                except:
                    pass

    def test_file2file(self):
        with gevent.Timeout(1):
            srcfile = open(self.TESTFILE, 'r')
            pipe = Pipe(0)
            dstfile = tempfile.NamedTemporaryFile(delete=False)
            
            try:
                pf = gevent.spawn_link_exception(pipe_to_file, pipe, dstfile)
                fp = gevent.spawn_link_exception(file_to_pipe, srcfile, pipe, 64)
                
                gevent.joinall([fp, pf])
                
                self.assertTrue(srcfile.closed)
                self.assertTrue(dstfile.closed)
                self.assertTrue(pipe.finished())

                self.assertEqualFiles(self.TESTFILE, dstfile.name)
                
            finally:
                try:
                    os.remove(file.name)
                except:
                    pass
                
    def test_put_to_closed_file(self):
        with gevent.Timeout(1):
            pipe = Pipe()
            file = open(os.devnull, 'w')
            
            pf = gevent.spawn_link_exception(pipe_to_file, pipe, file)
            
            # Wait for pipe_to_file to block
            while not pipe.getters:
                gevent.sleep(0)
            
            # Close file
            file.close()
            
            # Write something to pipe
            pipe.put('.')
            
            # Wait for pipe_to_file process to end
            pf.join()
            
            # Pipe should be closed now
            self.assertTrue(pipe.closed())
