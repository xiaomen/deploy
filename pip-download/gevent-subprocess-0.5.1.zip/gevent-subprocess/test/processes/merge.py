import sys

if __name__ == "__main__":
    while True:
        line1 = sys.stdin.readline()
        if not line1:
            break
        
        line2 = sys.stdin.readline()
        if not line2:
            break
        
        print line1.rstrip('\n')+'.'+line2.rstrip('\n')
