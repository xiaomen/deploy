import sys

if __name__ == "__main__":
    while True:
        line = sys.stdin.readline()
        if not line:
            break
        
        print ''.join(reversed(line.rstrip("\n")))
