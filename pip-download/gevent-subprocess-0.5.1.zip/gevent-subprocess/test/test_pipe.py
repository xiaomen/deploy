import unittest

import gevent
from gevsubprocess.pipe import Pipe, PipeClosed, Empty

def _blocktest(fn, *arg):
    try:
        fn(*arg)
    except PipeClosed:
        return True
    else:
        return False

def _blocktest2(pipe):
    try:
        fn(*arg)
    except PipeClosed:
        return True
    else:
        return False

class TestPipe(unittest.TestCase):
    def test_empty(self):
        with gevent.Timeout(1):
            pipe = Pipe()
            
            self.assertFalse(pipe.closed())
            self.assertFalse(pipe.finished())
            
            pipe.close()
            
            self.assertTrue(pipe.closed())
            self.assertTrue(pipe.finished())
        
    def test_get_raises_pipeclosed(self):
        with gevent.Timeout(1):
            pipe = Pipe()
            pipe.close()
            
            self.assertRaises(PipeClosed, pipe.get_nowait)
        
    def test_put_raises_pipeclosed(self):
        with gevent.Timeout(1):
            pipe = Pipe()
            pipe.close()
            
            self.assertRaises(PipeClosed, pipe.put, 1)

    def test_get_empty(self):
        with gevent.Timeout(1):
            pipe = Pipe()
            self.assertRaises(Empty, pipe.get_nowait)
        
    def test_put_and_get(self):
        with gevent.Timeout(1):
            pipe = Pipe()
            
            pipe.put(1)
    
            self.assertFalse(pipe.closed())
            self.assertFalse(pipe.finished())
            
            self.assertEqual(pipe.get_nowait(), 1)
    
            self.assertFalse(pipe.closed())
            self.assertFalse(pipe.finished())
    
            self.assertRaises(Empty, pipe.get_nowait)

    def test_put_and_get_closed(self):
        with gevent.Timeout(1):
            pipe = Pipe()
            
            pipe.put(1)
            pipe.close()
            
            self.assertTrue(pipe.closed())
            self.assertFalse(pipe.finished())
            
            self.assertEqual(pipe.get_nowait(), 1)
    
            self.assertTrue(pipe.closed())
            self.assertTrue(pipe.finished())
            
            self.assertRaises(PipeClosed, pipe.get_nowait)
            
    def test_blocked_get_raises(self):
        """ A blocked get() should raise PipeClosed as soon as the pipe is closed
        """
        with gevent.Timeout(1):
            pipe = Pipe(0)
            g = gevent.spawn(_blocktest, pipe.get)
            while not pipe.getters:
                # Make sure pipe.get is blocking
                gevent.sleep(0)
            pipe.close()
            self.assertTrue(g.get(), 'pipe.get() did not raise PipeClosed as expected')

    def test_blocked_put_raises(self):
        """ A blocked put() should raise PipeClosed as soon as the pipe is closed
        """
        with gevent.Timeout(1):
            pipe = Pipe(0)
            g = gevent.spawn(_blocktest, pipe.put, None)
            while not pipe.putters:
                # Make sure pipe.put is blocking
                gevent.sleep(0)
            pipe.close()
            self.assertTrue(g.get(), 'pipe.put() did not raise PipeClosed as expected')
            
        