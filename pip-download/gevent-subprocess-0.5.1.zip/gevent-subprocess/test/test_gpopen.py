import unittest
import os.path
import sys

import gevent
from gevsubprocess import GPopen, PIPE, STDOUT

PROCESSES = os.path.join(os.path.dirname(__file__), 'processes')

class TestGPopen(unittest.TestCase):
    def test_communicate(self):
        """Test GPopen.communicate"""
        with gevent.Timeout(1):
            reverse_py = os.path.join(PROCESSES, 'reverse.py')
                         
            p = GPopen('%s -u "%s"' % (sys.executable, reverse_py), 
                       shell=True, stdin=PIPE, stdout=PIPE, stderr=PIPE)
            
            stdout, stderr = p.communicate('ABCDEF')
            self.assertEqual(stdout.strip(), 'FEDCBA')
            self.assertEqual(stderr.strip(), '')

    def test_interleaved_io(self):
        with gevent.Timeout(1):
            merge_py = os.path.join(PROCESSES, 'merge.py')
                         
            p = GPopen('%s -u "%s"' % (sys.executable, merge_py), 
                       shell=True, stdin=PIPE, stdout=PIPE, stderr=STDOUT)
            
            p.stdin.put("ABC\n")
            p.stdin.put("DEF\n")
            
            self.assertEqual(p.stdout.get().strip(), "ABC.DEF")
            
            p.stdin.put("GHI\n")
            p.stdin.put("JKL\n")
            
            self.assertEqual(p.stdout.get().strip(), "GHI.JKL")
            
            p.stdin.close()
            p.wait()
